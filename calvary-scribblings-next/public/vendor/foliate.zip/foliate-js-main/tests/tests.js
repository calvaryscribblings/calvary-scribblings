import './epubcfi-tests.js'
